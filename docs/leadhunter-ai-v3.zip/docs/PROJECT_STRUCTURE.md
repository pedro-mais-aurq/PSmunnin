# Estrutura do Projeto

Monorepo organizado em:
- `apps/`: aplicações deployáveis (api, worker, web)
- `packages/`: bibliotecas compartilhadas (domain-core, agents-toolkit, shared-sdk)
- `infra/`: infraestrutura como código (docker, terraform, kubernetes)
- `docs/`: documentação e ADRs
- `tests/e2e/`: testes end-to-end
