# ADR-001: Monorepo com Clean Architecture

## Status
Aceito

## Contexto
Necessidade de separar domínio de infraestrutura e permitir múltiplos deployables.

## Decisão
Adotar monorepo com packages compartilhados e apps independentes.

## Consequências
- Reutilização de domain-core entre API e Worker
- Build separado por app
- Complexidade de gestão de dependências
