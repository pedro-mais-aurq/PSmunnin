# Convenções de Desenvolvimento

- Python: PEP 8, type hints obrigatórios
- Commits: Conventional Commits (`feat:`, `fix:`, `refactor:`)
- Branches: `main`, `develop`, `feature/*`, `fix/*`
- Testes: pytest, cobertura mínima 80% no Score Engine
