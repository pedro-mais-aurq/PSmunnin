# LeadHunter AI

Sistema multiagente de prospecção B2B para desenvolvedores web e agências.

## Arquitetura
- **Monorepo**: apps + packages compartilhados
- **Clean Architecture**: domain-core isolado de frameworks
- **API**: FastAPI + PostgreSQL + Redis
- **Worker**: Celery + agentes de IA
- **Web**: Next.js

## Documentação
- Especificação completa: `docs/MASTER_CONTEXT.md`
- Estrutura do projeto: `docs/PROJECT_STRUCTURE.md`
- Convenções: `docs/DEVELOPMENT_CONVENTIONS.md`
- Decisões arquiteturais: `docs/ADRs/`

## Quick Start

```bash
cd infra/docker
docker compose up --build
```

## Estrutura
```
apps/
  api/         → FastAPI REST
  worker/      → Celery workers + agentes
  web/         → Next.js frontend
packages/
  domain-core/ → Entidades, Score Engine, eventos
  agents-toolkit/ → Prompts e parsers
  shared-sdk/  → HTTP client, event bus
infra/
  docker/      → Docker Compose
  kubernetes/  → Manifestos K8s
  terraform/   → IaC
```

## Testes
```bash
cd apps/api && pytest tests/ -v
cd apps/worker && pytest tests/ -v
```
